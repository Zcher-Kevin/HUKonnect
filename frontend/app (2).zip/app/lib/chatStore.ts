// app/lib/chatStore.ts
// Simple in-memory chat store with useSyncExternalStore.
// Swap to real API later (see BACKEND NOTES below).

import { useSyncExternalStore } from "react";

export type Message = {
  id: string;
  chatId: string;        // "dm:<userId>"
  peerId: string;        // other user's id
  senderId: string;      // my id or peerId
  text: string;
  createdAt: number;     // ms
  editedAt?: number;     // ms
  replyToId?: string;    // message id
};

export type Thread = {
  chatId: string;        // "dm:<userId>"
  peerId: string;
  peerName: string;
  peerAvatar?: string | null;
  lastMessageAt: number; // ms
  lastMessageText: string;
  unread: number;
};

const ME = "u_me";

// ---- trivial store ----
const state = {
  threads: new Map<string, Thread>(),
  messages: new Map<string, Message[]>(), // key: chatId
};
const subs = new Set<() => void>();
const emit = () => subs.forEach((fn) => fn());

export const chat = {
  // subscribe for React
  subscribe(fn: () => void) { subs.add(fn); return () => subs.delete(fn); },
  getSnapshot() { return { threads: state.threads, messages: state.messages }; },

  // queries
  listThreads(): Thread[] {
    return [...state.threads.values()].sort((a,b)=>b.lastMessageAt-a.lastMessageAt);
  },
  getMessages(chatId: string): Message[] {
    return (state.messages.get(chatId) || []).slice().sort((a,b)=>a.createdAt-b.createdAt);
  },

  // upserts
  ensureThread(peerId: string, peerName: string, peerAvatar?: string|null) {
    const chatId = `dm:${peerId}`;
    if (!state.threads.has(chatId)) {
      state.threads.set(chatId, {
        chatId, peerId, peerName, peerAvatar: peerAvatar || null,
        lastMessageAt: 0, lastMessageText: "", unread: 0,
      });
    }
    if (!state.messages.has(chatId)) state.messages.set(chatId, []);
    return chatId;
  },

  send(peerId: string, peerName: string, text: string, opts?: { replyToId?: string }) {
    const chatId = chat.ensureThread(peerId, peerName);
    const msg: Message = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2,6)}`,
      chatId, peerId, senderId: ME, text, createdAt: Date.now(),
      replyToId: opts?.replyToId,
    };
    state.messages.get(chatId)!.push(msg);
    const th = state.threads.get(chatId)!;
    th.lastMessageAt = msg.createdAt;
    th.lastMessageText = text;
    emit();
    return msg;
  },

  edit(chatId: string, id: string, newText: string) {
    const arr = state.messages.get(chatId) || [];
    const m = arr.find(x => x.id === id);
    if (!m) return;
    m.text = newText;
    m.editedAt = Date.now();
    if (arr[arr.length-1]?.id === id) {
      const th = state.threads.get(chatId);
      if (th) th.lastMessageText = newText;
    }
    emit();
  },

  remove(chatId: string, id: string) {
    const arr = state.messages.get(chatId) || [];
    const idx = arr.findIndex(x => x.id === id);
    if (idx >= 0) arr.splice(idx, 1);
    const last = arr[arr.length-1];
    const th = state.threads.get(chatId);
    if (th) {
      th.lastMessageAt = last?.createdAt || th.lastMessageAt;
      th.lastMessageText = last?.text || "";
    }
    emit();
  },
};

// ---- React hook wrappers ----
export function useThreads() {
  const snap = useSyncExternalStore(chat.subscribe, chat.getSnapshot, chat.getSnapshot);
  return chat.listThreads();
}
export function useMessages(chatId: string) {
  const snap = useSyncExternalStore(chat.subscribe, chat.getSnapshot, chat.getSnapshot);
  return chat.getMessages(chatId);
}

/* ===================== BACKEND NOTES =====================
Endpoints (suggested):
  GET /chats              -> Thread[]
  GET /chats/:chatId      -> { thread, messages: Message[] }
  GET /chats/:chatId?before=<ts>&limit=50  (pagination)
  POST /chats/:chatId/messages { text, replyToId? } -> Message
  PATCH /chats/:chatId/messages/:id { text }        -> Message (editedAt set)
  DELETE /chats/:chatId/messages/:id
Auth: Bearer <JWT>

Wire-up plan:
- Replace send/edit/remove with axios calls, then update store with API responses.
- Replace ensureThread bootstrap with server threads (load on app start / tab focus).
========================================================= */
